import random


class Sucursal:
    def __init__(self,a,s,d,f,e):
        self.codigo=a
        self.descripcion=s
        self.mes=d
        self.sucursal=f
        self.importe=e

def carga(x):
    v=[0]*x
    for i in range(x):
        co=random.randint(0,100)
        des=random.randint(0,200)
        mes=random.randint(0,12)
        suc=random.randint(0,2)
        importe=random.randint(0,20000)
        v[i]=Sucursal(co,des,mes,suc,importe)
    return  v

def prints(x):
    sal=''
    sal+='{:<15}'.format(' Codigo : '+str(x.codigo))
    sal+='{:<15}'.format('|Descripcion : '+str(x.descripcion))
    sal+='{:<15}'.format('|Mes : '+str(x.mes))
    sal+='{:<15}'.format('|Sucursal : '+str(x.sucursal))
    sal+='{:<15}'.format('|Importe : '+str(x.importe))
    print()
    return sal
