import os
import pickle

from  ad_gastos_support import *

def menu():
    print('1- Cargar los n registros de gastos en un vector.')
    print('2- Mostrar el vector de gastos.')
    print('3- Generar un archivo con aquellos gastos cuyo importe supere cierto valor.')
    print('4- Mostrar el archivo.')
    print('5- Generar una matriz de acumulación a partir del archivo generado en el punto 3,que represente el gasto total por mes y sucursal.')
    print('6- A partir de la matriz, totalizar los gastos de un determinado mes.')
    print()


def punto_dos(vec):
   for i in range(len(vec)):
       print(prints(vec[i]))


def punto_tres(valor, fd,vec):

         m = open(fd,'wb')
         for i in vec:
                if i .importe >= valor:
                    pickle.dump(i,m)
                    m.flush()
         m.close()
         return  fd


def punto_cuatro(fd):
    m=open(fd,'rb')
    t=os.path.getsize(fd)

    if not os.path.exists(fd):
        print('El archivo no existe')
    else:
            while m.tell() < t:
                    a=pickle.load(m)
                    print(prints(a))


def punto_cinco(fd):
    matriz=[[0]*12 for i in range(2)]
    m=open(fd,'rb')
    t=os.path.getsize(fd)

    while m.tell() < t:
        aux = pickle.load(m)
        fila=aux.mes
        col=aux.sucursal
        matriz[fila][col]+=1
    print(matriz)
    return matriz


def punto_seis(matriz):
    pass


def main():
    x=-1
    vec=list()
    fd='Data_sucursal.dat'
    
    while x != 0:
        menu()

        x=int(input(' opcion :'))

        if x == 1:
            #y=int(input('Ingrese cuantos datos desea cargar :'))
            vec=carga(22)
        if x == 2:
            punto_dos(vec)
        if x == 3:
            valor=int(input('Ingrese valor :'))
            fd = punto_tres(valor,fd,vec)
        if x == 4:
            punto_cuatro(fd)
        if x == 5:
            matriz=punto_cinco(fd)
        if x == 6:
            pass

main()
